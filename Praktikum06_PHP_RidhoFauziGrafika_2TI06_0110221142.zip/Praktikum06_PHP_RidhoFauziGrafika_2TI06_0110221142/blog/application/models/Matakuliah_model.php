<?php 

    class Matakuliah_model extends CI_Model {
        public $nama;
        public $sks;
        public $kode;
    }

?>